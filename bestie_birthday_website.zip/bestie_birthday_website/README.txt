BESTIE BIRTHDAY WEBSITE — QUICK START

1. Open index.html in a text editor and find QUICK PERSONALIZATION near the bottom.
2. Replace YOUR BESTIE'S NAME and YOUR NAME with your names. You can edit the birthday letter and photo captions directly in the HTML.
3. Put up to four pictures in the photos folder named photo1.jpg, photo2.jpg, photo3.jpg, photo4.jpg.
4. Preview index.html in a browser. The photo placeholders are normal until you add your pictures.
5. To publish for free: create/sign in to GitHub, make a new PUBLIC repository (for example, bestie-birthday), upload index.html and the photos folder with your images, then open Settings → Pages. Under Build and deployment, choose Deploy from a branch, select main and / (root), and Save. Wait for the published URL to appear in Settings → Pages.
6. Send that URL to your bestie. Test it on your phone first.

Privacy: a public GitHub Pages website can be opened by anyone with the link and may be discoverable. Avoid posting private information or photos your friend would not want shared.
